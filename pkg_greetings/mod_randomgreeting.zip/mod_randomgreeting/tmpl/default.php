<?php
/**
 * @package     Greetins
 * @subpackage  mod_randomgreeting
 *
 * @copyright   2024 Nasim Kajal
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// no direct access
\defined('_JEXEC') or die;
?>

<?php if (!empty($msg)) { ?>
   <div class="mod-greeting mod-greeting-message-<?php echo $module->id; ?> <?php echo $moduleclass_sfx; ?>">   
		<p>
			<?php echo $msg->title . ': ' . $msg->greeting; ?>
		</p>
   </div>
<?php } ?>
