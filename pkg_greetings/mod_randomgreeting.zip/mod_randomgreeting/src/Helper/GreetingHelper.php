<?php
/**
 * @package     Greetins
 * @subpackage  mod_randomgreeting
 *
 * @copyright   2024 Nasim Kajal
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace Softune\Module\Randomgreeting\Site\Helper;

// no direct access
\defined('_JEXEC') or die;

use \Joomla\CMS\Application\SiteApplication;
use \Joomla\Database\DatabaseAwareInterface;
use \Joomla\Database\DatabaseAwareTrait;
use \Joomla\CMS\Factory;

/**
 * Helper for mod_randomgreeting
 *
 * @since  1.6
 */
class GreetingHelper implements DatabaseAwareInterface {
	
	use DatabaseAwareTrait;

	/**
     * Retrieve a greeting message
     *
     * @param   Registry       $params  The module parameters.
     * @param   ArticlesModel  $model   The model.
     *
     * @return  mixed
     *
     * @since   4.2.0
     */
	public static function getData($params, $app)
	{
		/** @var ArticlesModel $model */
        $model	= $app->bootComponent('com_greetings')->getMVCFactory()->createModel('Greeting', 'Site', ['ignore_request' => true]);
		$msg	= $model->getGreeting();
		
		return $msg;
	}
}
