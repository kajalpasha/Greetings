<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Greetings
 * @author     Nasim Kajal <nasimkajal@gmail.com>
 * @copyright  2024 Nasim Kajal
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Softune\Component\Greetings\Api\View\XXX_UCFIRST_INTERNAL_NAME_XXX;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\JsonApiView as BaseApiView;

/**
 * The XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXX view
 *
 * @since  1.0.0
 */
class JsonApiView extends BaseApiView
{
	/**
	 * The fields to render item in the documents
	 *
	 * @var    array
	 * @since  1.0.0
	 */
	protected $fieldsToRenderItem = [

	];

	/**
	 * The fields to render items in the documents
	 *
	 * @var    array
	 * @since  1.0.0
	 */
	protected $fieldsToRenderList = [

	];
}