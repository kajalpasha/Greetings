CREATE TABLE IF NOT EXISTS `#__greetings` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255)  NOT NULL,
  `greeting` TEXT NOT NULL,
  `checked_out` INT(11)  UNSIGNED,
  `checked_out_time` DATETIME NULL  DEFAULT NULL ,
  `created_by` INT(11)  NULL  DEFAULT 0,
  `modified_by` INT(11)  NULL  DEFAULT 0,
  `state` TINYINT(1)  NULL  DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_checked_out` (`checked_out`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_modified_by` (`modified_by`),
  KEY `idx_state` (`state`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

