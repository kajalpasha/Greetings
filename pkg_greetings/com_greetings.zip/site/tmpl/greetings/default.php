<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Greetings
 * @author     Nasim Kajal <nasimkajal@gmail.com>
 * @copyright  2024 Nasim Kajal
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
\defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Session\Session;
use \Joomla\CMS\User\UserFactoryInterface;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

$user       = Factory::getApplication()->getIdentity();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');

// Import CSS
$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_greetings.list');
?>

<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post" name="adminForm" id="adminForm">
	<?php if(!empty($this->filterForm)) { echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); } ?>
	<div class="table-responsive">
		<table class="table table-striped" id="greetingList">
			<thead>
				<tr>
					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_GREETINGS_GREETINGS_ID', 'a.id', $listDirn, $listOrder); ?>
					</th>
					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_GREETINGS_GREETINGS_TITLE', 'a.title', $listDirn, $listOrder); ?>
					</th>
					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_GREETINGS_GREETINGS_GREETING', 'a.greeting', $listDirn, $listOrder); ?>
					</th>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
						<div class="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
						</div>
					</td>
				</tr>
			</tfoot>
			<tbody>
				<?php foreach ($this->items as $i => $item) : ?>
					<tr class="row<?php echo $i % 2; ?>">						
						<td>
							<?php echo $item->id; ?>
						</td>
						<td>
							<?php echo $this->escape($item->title); ?>
						</td>
						<td>
							<?php echo $item->greeting; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<input type="hidden" name="task" value=""/>
	<input type="hidden" name="boxchecked" value="0"/>
	<input type="hidden" name="filter_order" value=""/>
	<input type="hidden" name="filter_order_Dir" value=""/>
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<?php
	if($canDelete) {
		$wa->addInlineScript("
			jQuery(document).ready(function () {
				jQuery('.delete-button').click(deleteItem);
			});

			function deleteItem() {

				if (!confirm(\"" . Text::_('COM_GREETINGS_DELETE_MESSAGE') . "\")) {
					return false;
				}
			}
		", [], [], ["jquery"]);
	}
?>